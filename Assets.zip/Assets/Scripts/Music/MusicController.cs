using System.Collections;
using System.Collections.Generic;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class MusicController : MonoBehaviour
{
    [SerializeField] private Button _switchSoundStatusBTN;
    [SerializeField] private TMP_Text _soundStatusLabel;

    private bool _isMuted = false;

    public void SwitchSoundStatus()
    { 
        _isMuted = !_isMuted;

        if (_isMuted) _soundStatusLabel.SetText("OFF");
        else _soundStatusLabel.SetText("ON");
    }
}
