using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Cross : MonoBehaviour
{

    [SerializeField] private float _rotationSpeed = 60f;
    private enum _direction {right, left}

    [SerializeField] private _direction _dir = _direction.right;
    private int _dirValue = 100;

    [Header("Random")]
    public bool isRandom = false;
    public int minRotationSpeed;
    public int maxRotationSpeed;

    private void Start()
    {
        if (isRandom) { _rotationSpeed = Random.Range(minRotationSpeed, maxRotationSpeed); }


        if(_dir == _direction.right) _dirValue = 1;
        if(_dir == _direction.left) _dirValue = -1;
    }

    void Update()
    {
        transform.Rotate(new Vector3(0f, 0f, _rotationSpeed * _dirValue * Time.deltaTime));
    }
}