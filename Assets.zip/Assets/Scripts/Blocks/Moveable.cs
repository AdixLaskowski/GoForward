using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Moveable : MonoBehaviour
{
    [SerializeField] private Transform _startPointTransform;
    [SerializeField] private Transform _endPointTransform;
    [SerializeField] private float speed = 1f;
    private enum _direction { right, left, up, down }
    [SerializeField] private _direction dir;


    // Update is called once per frame
    void Update()
    {
        if (!_startPointTransform || !_endPointTransform) return;


        if (dir == _direction.right)
        {

            if (transform.position.x < _endPointTransform.position.x)
            {

                transform.position = transform.position + new Vector3(speed * Time.deltaTime, 0, 0);
            }
            else
            {

                dir = _direction.left;

            }
        }
        else
        {

            if (transform.position.x > _startPointTransform.position.x)
            {

                transform.position = transform.position + new Vector3(-speed * Time.deltaTime, 0, 0);
            }
            else
            {

                dir = _direction.right;

            }
        }

        if (dir == _direction.up)
        {
            if (transform.position.y < _endPointTransform.position.y)
            {
                transform.position = transform.position + new Vector3(0, speed * Time.deltaTime, 0);
            }
            else
            {

                dir = _direction.down;
            }

        }
        else if (dir == _direction.down)
        {
            if (transform.position.y < _startPointTransform.position.y)
            {
                transform.position = transform.position + new Vector3(0, speed * Time.deltaTime, 0);
            }
            else
            {
                dir = _direction.up;
            }
        }
    }
}