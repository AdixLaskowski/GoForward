using System.Collections;
using System.Collections.Generic;
using System.Linq;
using UnityEngine;

public class PlayMode : MonoBehaviour
{
    List<GameObject> levels = new List<GameObject>();

    [SerializeField] private GameObject _startLevel;
    [SerializeField] private float gameSpeed = 4f;

    public GameObject[] levelListArray;
    public List<GameObject> levelsList;
    GameObject levelToBuild;
    GameObject newlevel;

    private bool canSpawn = true;

    [SerializeField] private GameObject _pausePanel;
    [SerializeField] private Transform parent;

    [SerializeField] private AudioSource Soundtrack;

    public void Pause()
    {
        _pausePanel.SetActive(true);
        Time.timeScale = 0;
        Soundtrack.Pause();
    }

    private void GoDown()
    {
        if (levels.Count == 0) return;

        for (int i = 0, j = levels.Count; i < j; i++)
        {
            levels[i].transform.position += new Vector3(0f, -gameSpeed * Time.deltaTime, 0f);

            if (levels[levels.Count - 1].transform.position.y < 14 && canSpawn)
            {
                SpawnNewLevel();
                canSpawn = false;
            }

            if (levels[levels.Count - 1].transform.position.y < 0)
            {
                canSpawn = true;
                DestroyLevel();
            }
        }     
    }

    private void DestroyLevel()
    {        
        GameObject _toRemove;
        _toRemove = levels[0];
        levels.Remove(_toRemove);
        Destroy(_toRemove);
    }

    private void SpawnNewLevel()
    {//roomList.Count
        levelToBuild = levelsList[Random.Range(0, 7)];
        newlevel = Instantiate(levelToBuild, new Vector3(0, 14f, 0), Quaternion.identity);
        levels.Add(newlevel);
    }

    private void GetLevels()
    {
        levelListArray = Resources.LoadAll<GameObject>("Levels");
        levelsList = levelListArray.ToList();
    }

    void Start()
    {
        if (!PlayerPrefs.HasKey("musicValue")) Soundtrack.volume = 0.5f;
        else Soundtrack.volume = PlayerPrefs.GetFloat("musicValue");

        if (_startLevel)
        {
            levels.Add(_startLevel);
        }

        GetLevels();
    }

    void Update()
    {
       if(Time.timeScale > 0) GoDown();
    }
}
