using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PauseController : MonoBehaviour
{
    [SerializeField] AudioSource soundtrack;

    public void Resume()
    {
        Time.timeScale = 1f;
        Destroy(gameObject);
        soundtrack.UnPause();
    }

    public void OpenMenu() {     
        
        SceneManager.LoadScene("MainMenu");
        Time.timeScale = 1f;

    }
}
