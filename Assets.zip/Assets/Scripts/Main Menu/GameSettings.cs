using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using TMPro;
using UnityEngine.UI;

public class GameSettings : MonoBehaviour
{
    [Header("Percentage labels")]
    [SerializeField] private TMP_Text musicPercentage;
    [SerializeField] private TMP_Text soundsPercentage;

    [Header("Sliders")]
    [SerializeField] private Slider musicSlider;
    [SerializeField] private Slider soundsSlider;

    private float newValue;
    private int realValue;

    public void UpdateMusicPercentageValue()
    {
        newValue = musicSlider.value * 100;
        realValue = (int)newValue;
        musicPercentage.text = $"{realValue}%";
    }

    public void UpdateSoundsPercentageValue()
    {
        newValue = soundsSlider.value * 100;
        realValue = (int)newValue;
        soundsPercentage.text = $"{realValue}%";    
    }
}
