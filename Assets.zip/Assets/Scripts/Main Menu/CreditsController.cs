using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CreditsController : MonoBehaviour
{
    public void GoToYoutube()
    {
        Application.OpenURL("https://www.youtube.com/channel/UC_gISmLeJwnln33EM70uaPw");
    }

    public void GoToFreesound()
    {
        Application.OpenURL("https://freesound.org/people/djfroyd/sounds/349708/");
    }

    public void GoToassetstore()
    {
        Application.OpenURL("https://assetstore.unity.com/packages/2d/gui/dark-theme-ui-199010");
    }
}
