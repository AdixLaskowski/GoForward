using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class SaveSettings : MonoBehaviour
{
    [SerializeField] ToggleGroup _colors;
    Toggle currentToggle;
    public enum playerColors { blue, lime, white, purple, yellow, pink, orange, cyan, green, brown}
    public playerColors newPlayerColor;
    private Color currentPlayerColor;
    public int toggleId;

    [SerializeField] private GameObject mainMenuController;

    // Customization

    public void ExitCustomization()
    {
        SaveAllSettings();
        mainMenuController.GetComponent<MainMenuController>().SetNewColorForSettings();
    }


    private void Start()
    {
        currentToggle = GetComponent<Toggle>();
        if (toggleId == PlayerPrefs.GetInt("currentToggleId"))
        {
            currentToggle.isOn = true;
        }     
    }

    public void SetColorAsCurrent()
    {
        currentToggle = GetComponent<Toggle>();
        currentPlayerColor = currentToggle.colors.normalColor;

        PlayerPrefs.SetFloat("currentPlayerColor_R", currentPlayerColor.r);
        PlayerPrefs.SetFloat("currentPlayerColor_G", currentPlayerColor.g);
        PlayerPrefs.SetFloat("currentPlayerColor_B", currentPlayerColor.b);

        PlayerPrefs.SetInt("currentToggleId", toggleId);
    }


    public void SaveAllSettings() => PlayerPrefs.Save();
}
