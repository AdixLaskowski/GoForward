using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class Settings : MonoBehaviour
{
    private float musicValue = 0.5f;
    private float sfxValue = 0.5f;
    private int vibrateValue = 1;
    private int invertMovementValue = 0;

    [SerializeField] private Slider musicSlider;
    [SerializeField] private Slider sfxSlider;
    [SerializeField] private Toggle clickSoundToggle;
    [SerializeField] private Toggle vibrateToggle;
    [SerializeField] private Toggle invertMovementToggle;

    void Start()
    {
        if (!PlayerPrefs.HasKey("musicValue")) musicValue = 0.5f;
        else { musicValue = PlayerPrefs.GetFloat("musicValue"); }

        if (!PlayerPrefs.HasKey("sfxValue")) sfxValue = 0.5f;
        else { sfxValue = PlayerPrefs.GetFloat("sfxValue"); }

        if (!PlayerPrefs.HasKey("vibrateValue")) vibrateValue = 1;
        else { vibrateValue = PlayerPrefs.GetInt("vibrateValue"); }

        if (!PlayerPrefs.HasKey("invertMovementValue")) invertMovementValue = 0;
        else { invertMovementValue = PlayerPrefs.GetInt("invertMovementValue"); }

        // Load Settings       
        musicSlider.value = musicValue;
        sfxSlider.value = sfxValue;
        vibrateToggle.isOn = true ? vibrateValue == 1 : false;
        invertMovementToggle.isOn = true ? invertMovementValue == 1 : false;
    }

    public void ExitSettings()
    {
        PlayerPrefs.SetFloat("musicValue", musicSlider.value);
        PlayerPrefs.SetFloat("sfxValue", sfxSlider.value);

        if (vibrateToggle.isOn == true) { vibrateValue = 1; } else { vibrateValue = 0; }
        PlayerPrefs.SetInt("vibrateValue", vibrateValue);

        if (invertMovementToggle.isOn == true) { invertMovementValue = 1; } else { invertMovementValue = 0; }
        PlayerPrefs.SetInt("invertMovementValue", invertMovementValue);

        PlayerPrefs.Save();
    }

    public void Vibrate()
    {
        if (vibrateToggle.isOn == true)
            Handheld.Vibrate();
    }

}
