using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class HowToPlayController : MonoBehaviour
{
    [SerializeField] private Button previousPageButton;
    [SerializeField] private Button nextPageButton;
    [SerializeField] private TMP_Text pageNumber;
    [SerializeField] private GameObject firstPage;
    [SerializeField] private GameObject secondPage;

    void Start() => PreviousPage();

    public void NextPage()
    {
        previousPageButton.gameObject.SetActive(true);
        nextPageButton.gameObject.SetActive(false);
        firstPage.SetActive(false);
        secondPage.SetActive(true);
        pageNumber.text = "2/2";
    }

    public void PreviousPage()
    {
        previousPageButton.gameObject.SetActive(false);
        nextPageButton.gameObject.SetActive(true);
        secondPage.SetActive(false);
        firstPage.SetActive(true);
        pageNumber.text = "1/2";
    }

    
}
