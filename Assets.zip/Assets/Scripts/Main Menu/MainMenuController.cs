using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;
using TMPro;

public class MainMenuController : MonoBehaviour
{
    [SerializeField] private GameObject colorSelection;
    [SerializeField] private GameObject settingsSelection;
    [SerializeField] private GameObject instructions;
    [SerializeField] private GameObject credits;

    [SerializeField] private Image settingInnerImage;
    [SerializeField] private Button settingButton;
    [SerializeField] private TMP_Text bestScoreValue;
    private float newRed, newBlue, newGreen;

    public void SetNewColorForSettings()
    {
        newRed = PlayerPrefs.GetFloat("currentPlayerColor_R");
        newBlue = PlayerPrefs.GetFloat("currentPlayerColor_G");
        newGreen = PlayerPrefs.GetFloat("currentPlayerColor_B");

        settingButton.image.color = new Color(newRed, newBlue, newGreen, 1);
        settingInnerImage.color = new Color(newRed, newBlue, newGreen, 1);
    }

    private void Start()
    {
        SetNewColorForSettings();
        bestScoreValue.text = PlayerPrefs.GetInt("BestScore").ToString();
    }

    public void StartGame() => SceneManager.LoadScene("Gameplay");

    public void OpenColorSelection() => colorSelection.SetActive(true);

    public void OpenSettings() => settingsSelection.SetActive(true);

    public void OpenInstractions() => instructions.SetActive(true);

    public void OpenCredits() => credits.SetActive(true);

}
