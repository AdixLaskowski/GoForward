using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.EventSystems;
using UnityEngine.UI;
using UnityEngine.InputSystem;
using TMPro;

public class Movement : MonoBehaviour
{
    [SerializeField] private float speed = 0.02f;

    private bool touch = false;
    private bool newTouch = false;

    float touchPosX;
    float newTouchPosX;

    bool isTouchActive = false;
    bool isNewTouchActive = false;

    private bool isMovementInverted;


    private void Start()
    {
        isMovementInverted = true ? PlayerPrefs.GetInt("invertMovementValue") == 1 : false;
    }

    public void TouchPressed(InputAction.CallbackContext context)
    {
        if (context.started) { touch = true; }

        if (context.performed)
        {
            newTouch = false;
            touch = true;
            isTouchActive = true;
        }

        if (context.canceled)
        {
            touch = false;

            if(isNewTouchActive)
                isTouchActive = false;
        }

    }

    public void NewTouchPressed(InputAction.CallbackContext context)
    {
        if (context.started) { newTouch = true; }

        if (context.performed)
        {
            touch = false;
            newTouch = true;
            isNewTouchActive = true;
        }

        if (context.canceled)
        {
            newTouch = false;
            isNewTouchActive = false;

            if (isTouchActive)
                touch = true;
        }
    }


    public void GetTouchPositionX(InputAction.CallbackContext context)
    {
        touchPosX = context.ReadValue<float>();
    }

    public void GetNewTouchPositionX(InputAction.CallbackContext context)
    {
        newTouchPosX = context.ReadValue<float>();
    }


    private void Update()
    {
        if (Time.timeScale == 0) return;

        if (isMovementInverted == false)
        {
            if (touch)
            {

                if (touchPosX < Screen.width / 2)
                {
                    transform.position += new Vector3(-speed, 0f, 0f);

                }

                if (touchPosX > Screen.width / 2)
                {

                    transform.position += new Vector3(speed, 0f, 0f);
                }

            }


            if (newTouch)
            {

                if (newTouchPosX < Screen.width / 2)
                {
                    transform.position += new Vector3(-speed, 0f, 0f);

                }

                if (newTouchPosX > Screen.width / 2)
                {

                    transform.position += new Vector3(speed, 0f, 0f);
                }

            }
        }
        else {

            if(touch)
            {

                if (touchPosX < Screen.width / 2)
                {
                    transform.position += new Vector3(speed, 0f, 0f);

                }

                if (touchPosX > Screen.width / 2)
                {

                    transform.position += new Vector3(-speed, 0f, 0f);
                }

            }


            if (newTouch)
            {

                if (newTouchPosX < Screen.width / 2)
                {
                    transform.position += new Vector3(speed, 0f, 0f);

                }

                if (newTouchPosX > Screen.width / 2)
                {

                    transform.position += new Vector3(-speed, 0f, 0f);
                }

            }


        }
    }

}
