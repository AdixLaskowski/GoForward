using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Rendering.Universal;

public class PlayerEffects : MonoBehaviour
{

    private SpriteRenderer playerColor;
    private float newRed, newBlue, newGreen;
    private Light2D playerLight;

    void Start()
    {
        playerColor = GetComponent<SpriteRenderer>();
        playerLight = transform.GetChild(0).GetComponent<Light2D>();

        newRed = PlayerPrefs.GetFloat("currentPlayerColor_R");
        newBlue = PlayerPrefs.GetFloat("currentPlayerColor_G");
        newGreen = PlayerPrefs.GetFloat("currentPlayerColor_B");

        playerColor.color = new Color(newRed, newBlue, newGreen, 1);
        playerLight.color = new Color(newRed, newBlue, newGreen, 1);
    }
}
