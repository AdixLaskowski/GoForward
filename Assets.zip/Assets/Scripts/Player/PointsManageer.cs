using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class PointsManageer : MonoBehaviour
{

    [SerializeField] private int points;
    [SerializeField] private TMP_Text pointCount;
    [SerializeField] private GameObject gameOverPanel;
    

    [Header("Sounds")]
    [SerializeField] private AudioSource soundtrack;
    [SerializeField] private AudioSource getPointSound;
    [SerializeField] private AudioSource failureSound;
    private bool canVibrate;
    private int bestScore;

    void Start()
    {
        bestScore = PlayerPrefs.GetInt("BestScore");
        points = 0;
        canVibrate = true ? PlayerPrefs.GetInt("vibrateValue") == 1 : false;

        if (!PlayerPrefs.HasKey("sfxValue"))
        {

            getPointSound.volume = 0.5f;
            failureSound.volume = 0.5f;
        }
        else
        {
            getPointSound.volume = PlayerPrefs.GetFloat("sfxValue");

            if (PlayerPrefs.GetFloat("sfxValue") != 0)
            {
                failureSound.volume = PlayerPrefs.GetFloat("sfxValue") + 0.2f;
            }
            else { failureSound.volume = 0; }
        }
    }


    private void OnTriggerEnter2D(Collider2D other)
    {

        if (other.gameObject.CompareTag("danger"))
        {
            soundtrack.Stop();

            failureSound.Play();

            if (canVibrate) Handheld.Vibrate();

            gameOverPanel.SetActive(true);
            Time.timeScale = 0;

            GameOver.currentScoreValue = points;

            if(points > bestScore) PlayerPrefs.SetInt("BestScore", points);

        }

        if (other.gameObject.CompareTag("Finish"))
        {
            getPointSound.Play();
            StartCoroutine(ChangePointCounterColor());
            points++;

            pointCount.text = points.ToString(); 

        }
    }



    private IEnumerator ChangePointCounterColor()
    {
        pointCount.color = new Color(0.1f, 0.9f, 0.2f, 1f);
        pointCount.fontSize = 130;

        yield return new WaitForSecondsRealtime(0.5f);

        pointCount.color = new Color(1f, 1f, 1f, 1f);
        pointCount.fontSize = 110;
    }
}
